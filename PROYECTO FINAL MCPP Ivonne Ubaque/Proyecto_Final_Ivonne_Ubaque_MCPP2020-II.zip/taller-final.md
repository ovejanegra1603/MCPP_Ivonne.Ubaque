```python
import re
import nltk
import requests
from bs4 import BeautifulSoup
import numpy as np
from nltk.book import *
import matplotlib.pyplot as plt
import tabulate as tab

html = requests.get('http://www.fedearroz.com.co/new/noticias.php').text
soup = BeautifulSoup(html)
type(soup)

soup
links = soup.find_all('a',onclick=True)
links

```




    [<a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3223', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3224', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3221', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3207', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3206', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3200', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3199', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3198', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3220', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3197', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3196', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3202', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3203', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3204', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3208', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3209', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3210', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3211', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3173', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3171', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3170', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3169', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3217', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3219', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3214', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3215', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3216', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3218', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3194', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3195', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3213', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3186', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3187', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3193', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3182', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3183', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3184', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3185', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3178', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3179', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3180', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3181', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3174', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3176', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3188', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3189', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3190', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3191', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3192', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3158', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3159', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3160', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3161', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3162', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3163', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3164', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3154', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3157', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3155', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3153', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3165', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3166', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3167', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3168', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3148', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3149', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3147', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3145', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3146', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3144', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3139', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3133', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3134', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3135', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3136', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3137', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3138', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3143', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3140', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3141', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3150', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3151', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3152', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3130', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3131', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3132', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3142', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3125', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3124', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3123', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3128', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3129', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3122', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3121', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3126', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3119', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3118', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3115', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3114', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3113', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3111', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3109', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3110', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3106', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3108', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3105', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3104', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3127', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3101', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3100', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3099', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3098', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3112', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3116', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3117', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3097', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3096', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3095', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3094', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3093', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3092', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3091', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3102', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3103', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3089', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3088', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3087', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3086', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3084', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3085', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3083', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3082', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3076', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3074', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3075', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3073', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3072', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3071', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3067', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3068', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3069', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3070', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3078', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3079', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3080', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3077', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3063', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3064', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3065', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3061', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3062', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3058', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3059', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3060', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3055', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3056', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3057', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3050', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3051', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3049', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3052', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3066', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3090', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3053', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2967', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2968', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2963', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3047', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3048', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3045', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3046', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3043', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3044', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3054', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3037', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3038', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3039', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3040', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3041', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3042', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2962', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3034', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3035', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3036', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3025', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3026', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3027', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3028', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3029', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3030', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3031', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3032', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3033', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3021', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3022', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3023', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3024', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3018', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3019', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3020', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2964', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2965', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2966', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3014', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3015', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3016', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3017', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3011', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3012', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3013', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3008', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3009', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3010', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3006', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3007', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3003', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3004', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3005', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3000', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3002', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2998', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2999', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=3001', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2996', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2997', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2994', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2995', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2990', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2991', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2993', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2988', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2989', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2985', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2986', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2987', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2961', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2982', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2983', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2984', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2981', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2980', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2977', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2960', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2973', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2974', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2975', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2976', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2978', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2979', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2971', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2972', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2952', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2953', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2970', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2949', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2950', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2951', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2969', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2948', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2944', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2945', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2946', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2947', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2943', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2942', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2941', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2954', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2955', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2956', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2957', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2958', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2959', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2937', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2936', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2928', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2929', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2930', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2931', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2932', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2933', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2934', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2921', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2922', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2923', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2924', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2925', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2926', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2911', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2912', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2913', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2914', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2915', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2916', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2917', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2905', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2907', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2908', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2909', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2910', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2897', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2898', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2899', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2900', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2901', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2902', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2903', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2938', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2939', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2940', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2889', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2890', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2891', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2893', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2894', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2895', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2896', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2918', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2919', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2920', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2927', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2883', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2884', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2885', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2886', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2887', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2888', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2882', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2877', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2878', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2879', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2880', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2881', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2875', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2866', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2867', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2868', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2869', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2870', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2871', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2873', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2874', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2863', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2864', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2865', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2876', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2859', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2860', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2861', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2862', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2852', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2853', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2854', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2855', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2856', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2857', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2858', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2845', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2846', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2848', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2849', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2850', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2851', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2992', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2823', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2824', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2825', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2826', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2827', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2828', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2829', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2830', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2831', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2832', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2833', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2834', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2835', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2836', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2837', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2838', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2839', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2840', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2841', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2842', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2843', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2844', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2822', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2818', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2819', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2820', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2817', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2816', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2811', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2812', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2813', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2814', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2815', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2808', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2807', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2806', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2800', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2801', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2802', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2803', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2804', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2805', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2792', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2793', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2794', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2795', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2796', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2797', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2798', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2799', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2791', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2790', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2789', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2784', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2785', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2786', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2787', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2780', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2781', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2782', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2783', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2771', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2772', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2773', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2774', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2775', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2776', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2777', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2778', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2779', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2764', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2765', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2766', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2767', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2768', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2769', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2770', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2754', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2755', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2756', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2757', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2758', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2759', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2760', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2748', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2749', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2750', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2751', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2752', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2753', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2744', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2745', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2746', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2747', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2741', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2742', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2743', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2740', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2736', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2737', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2738', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2739', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2729', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2730', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2731', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2732', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2733', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2734', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2726', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2727', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2728', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2723', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2724', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2725', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2761', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2721', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2715', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2717', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2718', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2719', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2720', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2722', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2712', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2711', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2710', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2707', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2708', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2709', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2705', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2706', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2704', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2703', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2701', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2702', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2762', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2763', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2699', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2700', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2692', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2693', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2694', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2695', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2696', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2697', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2690', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2683', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2684', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2685', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2686', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2687', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2688', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2666', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2667', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2668', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2669', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2670', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2671', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2672', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2673', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2674', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2675', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2676', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2677', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2681', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2680', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2682', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2657', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2658', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2659', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2660', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2661', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2662', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2663', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2664', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2665', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2649', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2650', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2651', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2652', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2653', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2654', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2655', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2656', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2639', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2640', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2641', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2643', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2644', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2645', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2646', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2647', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2648', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2631', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2632', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2633', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2634', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2635', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2636', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2637', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2638', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2614', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2615', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2616', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2617', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2618', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2619', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2620', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2621', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2622', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2623', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2624', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2625', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2626', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2627', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2628', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2629', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2630', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2602', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2601', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2603', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2604', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2596', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2597', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2598', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2585', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2586', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2587', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2588', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2589', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2590', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2591', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2592', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2593', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2594', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2569', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2570', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2571', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2572', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2573', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2574', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2575', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2576', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2577', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2578', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2579', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2580', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2581', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2582', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2583', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2584', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2562', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2563', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2564', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2565', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2566', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2567', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2568', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2551', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2552', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2553', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2554', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2555', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2556', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2557', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2689', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2543', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2544', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2545', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2546', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2547', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2548', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2549', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2550', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2612', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2538', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2539', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2540', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2541', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2542', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2611', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2613', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2535', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2536', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2537', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2526', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2527', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2528', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2529', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2530', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2531', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2532', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2533', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2534', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2525', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2516', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2517', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2518', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2519', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2520', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2521', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2522', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2523', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2524', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2515', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2512', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2513', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2514', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2511', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2510', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2509', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2502', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2503', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2504', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2505', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2506', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2507', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2508', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2500', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2501', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2559', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2560', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2561', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2691', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2499', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2494', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2495', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2496', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2497', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2498', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2492', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2493', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2558', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2605', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2606', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2607', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2609', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2610', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2491', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2489', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2473', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2474', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2475', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2483', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2484', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2485', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2465', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2466', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2467', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2468', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2469', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2470', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2471', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2472', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2459', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2460', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2461', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2462', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2463', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2454', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2455', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2456', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2457', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2458', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2450', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2451', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2452', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2453', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2436', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2437', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2438', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2439', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2440', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2443', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2488', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2430', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2431', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2432', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2433', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2434', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2435', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2464', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2476', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2477', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2478', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2481', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2482', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2429', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2426', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2427', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2428', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2423', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2424', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2425', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2479', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2416', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2417', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2418', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2419', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2420', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2421', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2422', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2480', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2412', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2413', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2414', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2415', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2406', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2405', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2407', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2408', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2409', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2410', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2411', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2399', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2400', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2381', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2382', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2383', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2442', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2378', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2379', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2380', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2371', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2372', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2373', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2374', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2375', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2376', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2377', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2368', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2369', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2370', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2353', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2354', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2355', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2441', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2385', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2351', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2352', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2349', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2350', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2386', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2387', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2347', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2348', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2344', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2345', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2388', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2444', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2389', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2390', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2341', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2342', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2343', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2337', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2339', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2340', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2391', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2392', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2336', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2393', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2333', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2334', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2335', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2331', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2332', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2394', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2395', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2445', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2384', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2396', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2359', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2360', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2361', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2397', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2357', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2358', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2446', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2447', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2448', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2330', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2356', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2449', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2325', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2326', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2327', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2328', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2329', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2364', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2322', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2323', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2324', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2362', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2363', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2365', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2366', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2367', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2320', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2321', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2398', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2402', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2403', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2317', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2318', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2319', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2315', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2316', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2313', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2311', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2312', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2314', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2307', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2308', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2309', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2305', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2306', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2303', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2304', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2301', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2302', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2299', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2300', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2296', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2297', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2298', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2293', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2294', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2295', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2290', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2291', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2292', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2287', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2288', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2289', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2283', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2284', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2285', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2286', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2281', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2282', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2276', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2277', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2278', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2279', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2280', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2273', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2274', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2275', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2269', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2270', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2271', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2272', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2490', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2260', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2261', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2262', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2255', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2256', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2257', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2259', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2251', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2252', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2253', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2254', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2245', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2246', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2247', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2248', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2250', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2264', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2266', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2267', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2241', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2242', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2243', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2244', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2239', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2240', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2236', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2237', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2238', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2233', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2234', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2235', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2229', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2230', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2231', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2232', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2225', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2226', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2222', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2223', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2224', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2219', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2220', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2221', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2216', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2217', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2218', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2268', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2213', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2214', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2215', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2212', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2207', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2208', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2209', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2211', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2204', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2205', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2206', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2210', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2201', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2202', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2203', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2198', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2199', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2200', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2195', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2196', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2191', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2192', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2194', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2183', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2184', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2185', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2186', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2189', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2190', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2180', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2181', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2182', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2177', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2178', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2179', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2174', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     <a ,="" href="#" onclick="MM_openBrWindow('../noticias/noticiasd2.php?id=2175', 'Noticia', 'scrollbars=yes, resizable=yes, width=700, height=550')" style="text-decoration:none; color:#009;">Ver noticia...</a>,
     ...]




```python
noticias = re.findall('id=+[0-9]+',str(links))
enlace = 'http://www.fedearroz.com.co/noticias/noticiasd2.php?'
datos = []
for i in range(len(noticias)):
    datos.append(enlace + noticias[i])
    print(datos[i])
print(len(datos))   
```

    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3223
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3224
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3221
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3207
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3206
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3200
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3199
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3198
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3220
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3197
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3196
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3202
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3203
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3204
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3208
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3209
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3210
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3211
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3173
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3171
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3170
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3169
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3217
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3219
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3214
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3215
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3216
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3218
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3194
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3195
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3213
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3186
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3187
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3193
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3182
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3183
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3184
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3185
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3178
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3179
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3180
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3181
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3174
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3176
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3188
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3189
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3190
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3191
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3192
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3158
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3159
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3160
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3161
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3162
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3163
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3164
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3154
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3157
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3155
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3153
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3165
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3166
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3167
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3168
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3148
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3149
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3147
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3145
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3146
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3144
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3139
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3133
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3134
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3135
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3136
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3137
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3138
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3143
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3140
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3141
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3150
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3151
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3152
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3130
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3131
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3132
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3142
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3125
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3124
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3123
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3128
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3129
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3122
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3121
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3126
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3119
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3118
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3115
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3114
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3113
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3111
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3109
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3110
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3106
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3108
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3105
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3104
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3127
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3101
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3100
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3099
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3098
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3112
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3116
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3117
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3097
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3096
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3095
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3094
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3093
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3092
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3091
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3102
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3103
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3089
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3088
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3087
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3086
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3084
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3085
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3083
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3082
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3076
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3074
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3075
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3073
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3072
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3071
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3067
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3068
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3069
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3070
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3078
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3079
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3080
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3077
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3063
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3064
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3065
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3061
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3062
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3058
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3059
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3060
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3055
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3056
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3057
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3050
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3051
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3049
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3052
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3066
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3090
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3053
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2967
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2968
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2963
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3047
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3048
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3045
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3046
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3043
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3044
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3054
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3037
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3038
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3039
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3040
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3041
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3042
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2962
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3034
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3035
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3036
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3025
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3026
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3027
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3028
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3029
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3030
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3031
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3032
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3033
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3021
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3022
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3023
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3024
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3018
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3019
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3020
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2964
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2965
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2966
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3014
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3015
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3016
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3017
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3011
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3012
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3013
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3008
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3009
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3010
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3006
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3007
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3003
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3004
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3005
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3000
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3002
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2998
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2999
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3001
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2996
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2997
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2994
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2995
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2990
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2991
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2993
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2988
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2989
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2985
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2986
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2987
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2961
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2982
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2983
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2984
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2981
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2980
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2977
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2960
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2973
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2974
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2975
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2976
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2978
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2979
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2971
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2972
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2952
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2953
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2970
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2949
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2950
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2951
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2969
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2948
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2944
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2945
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2946
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2947
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2943
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2942
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2941
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2954
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2955
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2956
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2957
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2958
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2959
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2937
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2936
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2928
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2929
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2930
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2931
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2932
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2933
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2934
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2921
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2922
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2923
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2924
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2925
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2926
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2911
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2912
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2913
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2914
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2915
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2916
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2917
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2905
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2907
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2908
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2909
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2910
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2897
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2898
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2899
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2900
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2901
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2902
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2903
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2938
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2939
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2940
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2889
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2890
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2891
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2893
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2894
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2895
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2896
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2918
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2919
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2920
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2927
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2883
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2884
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2885
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2886
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2887
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2888
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2882
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2877
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2878
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2879
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2880
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2881
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2875
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2866
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2867
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2868
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2869
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2870
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2871
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2873
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2874
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2863
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2864
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2865
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2876
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2859
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2860
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2861
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2862
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2852
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2853
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2854
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2855
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2856
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2857
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2858
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2845
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2846
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2848
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2849
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2850
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2851
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2992
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2823
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2824
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2825
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2826
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2827
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2828
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2829
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2830
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2831
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2832
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2833
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2834
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2835
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2836
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2837
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2838
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2839
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2840
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2841
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2842
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2843
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2844
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2822
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2818
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2819
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2820
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2817
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2816
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2811
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2812
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2813
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2814
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2815
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2808
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2807
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2806
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2800
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2801
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2802
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2803
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2804
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2805
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2792
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2793
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2794
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2795
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2796
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2797
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2798
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2799
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2791
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2790
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2789
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2784
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2785
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2786
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2787
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2780
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2781
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2782
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2783
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2771
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2772
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2773
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2774
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2775
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2776
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2777
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2778
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2779
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2764
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2765
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2766
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2767
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2768
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2769
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2770
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2754
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2755
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2756
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2757
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2758
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2759
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2760
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2748
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2749
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2750
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2751
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2752
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2753
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2744
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2745
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2746
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2747
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2741
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2742
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2743
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2740
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2736
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2737
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2738
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2739
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2729
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2730
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2731
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2732
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2733
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2734
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2726
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2727
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2728
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2723
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2724
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2725
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2761
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2721
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2715
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2717
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2718
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2719
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2720
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2722
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2712
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2711
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2710
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2707
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2708
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2709
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2705
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2706
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2704
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2703
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2701
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2702
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2762
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2763
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2699
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2700
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2692
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2693
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2694
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2695
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2696
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2697
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2690
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2683
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2684
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2685
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2686
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2687
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2688
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2666
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2667
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2668
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2669
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2670
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2671
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2672
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2673
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2674
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2675
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2676
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2677
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2681
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2680
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2682
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2657
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2658
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2659
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2660
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2661
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2662
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2663
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2664
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2665
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2649
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2650
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2651
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2652
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2653
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2654
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2655
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2656
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2639
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2640
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2641
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2643
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2644
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2645
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2646
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2647
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2648
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2631
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2632
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2633
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2634
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2635
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2636
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2637
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2638
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2614
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2615
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2616
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2617
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2618
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2619
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2620
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2621
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2622
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2623
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2624
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2625
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2626
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2627
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2628
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2629
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2630
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2602
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2601
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2603
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2604
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2596
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2597
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2598
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2585
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2586
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2587
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2588
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2589
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2590
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2591
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2592
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2593
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2594
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2569
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2570
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2571
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2572
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2573
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2574
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2575
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2576
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2577
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2578
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2579
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2580
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2581
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2582
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2583
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2584
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2562
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2563
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2564
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2565
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2566
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2567
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2568
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2551
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2552
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2553
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2554
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2555
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2556
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2557
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2689
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2543
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2544
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2545
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2546
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2547
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2548
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2549
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2550
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2612
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2538
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2539
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2540
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2541
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2542
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2611
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2613
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2535
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2536
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2537
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2526
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2527
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2528
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2529
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2530
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2531
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2532
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2533
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2534
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2525
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2516
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2517
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2518
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2519
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2520
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2521
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2522
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2523
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2524
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2515
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2512
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2513
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2514
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2511
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2510
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2509
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2502
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2503
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2504
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2505
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2506
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2507
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2508
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2500
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2501
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2559
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2560
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2561
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2691
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2499
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2494
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2495
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2496
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2497
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2498
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2492
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2493
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2558
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2605
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2606
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2607
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2609
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2610
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2491
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2489
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2473
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2474
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2475
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2483
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2484
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2485
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2465
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2466
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2467
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2468
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2469
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2470
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2471
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2472
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2459
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2460
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2461
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2462
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2463
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2454
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2455
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2456
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2457
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2458
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2450
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2451
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2452
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2453
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2436
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2437
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2438
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2439
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2440
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2443
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2488
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2430
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2431
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2432
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2433
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2434
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2435
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2464
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2476
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2477
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2478
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2481
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2482
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2429
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2426
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2427
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2428
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2423
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2424
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2425
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2479
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2416
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2417
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2418
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2419
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2420
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2421
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2422
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2480
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2412
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2413
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2414
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2415
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2406
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2405
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2407
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2408
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2409
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2410
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2411
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2399
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2400
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2381
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2382
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2383
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2442
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2378
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2379
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2380
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2371
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2372
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2373
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2374
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2375
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2376
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2377
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2368
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2369
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2370
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2353
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2354
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2355
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2441
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2385
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2351
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2352
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2349
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2350
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2386
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2387
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2347
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2348
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2344
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2345
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2388
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2444
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2389
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2390
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2341
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2342
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2343
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2337
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2339
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2340
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2391
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2392
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2336
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2393
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2333
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2334
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2335
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2331
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2332
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2394
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2395
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2445
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2384
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2396
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2359
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2360
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2361
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2397
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2357
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2358
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2446
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2447
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2448
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2330
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2356
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2449
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2325
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2326
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2327
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2328
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2329
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2364
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2322
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2323
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2324
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2362
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2363
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2365
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2366
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2367
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2320
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2321
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2398
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2402
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2403
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2317
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2318
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2319
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2315
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2316
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2313
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2311
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2312
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2314
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2307
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2308
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2309
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2305
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2306
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2303
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2304
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2301
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2302
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2299
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2300
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2296
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2297
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2298
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2293
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2294
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2295
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2290
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2291
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2292
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2287
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2288
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2289
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2283
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2284
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2285
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2286
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2281
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2282
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2276
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2277
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2278
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2279
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2280
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2273
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2274
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2275
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2269
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2270
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2271
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2272
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2490
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2260
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2261
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2262
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2255
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2256
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2257
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2259
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2251
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2252
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2253
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2254
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2245
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2246
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2247
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2248
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2250
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2264
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2266
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2267
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2241
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2242
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2243
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2244
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2239
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2240
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2236
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2237
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2238
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2233
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2234
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2235
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2229
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2230
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2231
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2232
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2225
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2226
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2222
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2223
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2224
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2219
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2220
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2221
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2216
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2217
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2218
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2268
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2213
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2214
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2215
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2212
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2207
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2208
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2209
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2211
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2204
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2205
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2206
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2210
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2201
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2202
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2203
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2198
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2199
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2200
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2195
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2196
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2191
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2192
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2194
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2183
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2184
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2185
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2186
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2189
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2190
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2180
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2181
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2182
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2177
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2178
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2179
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2174
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2175
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2176
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2171
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2172
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2173
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2265
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2168
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2169
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2164
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2165
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2166
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2167
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2161
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2162
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2163
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2157
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2158
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2160
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2152
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2153
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2155
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2156
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2147
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2148
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2149
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2150
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2151
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2140
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2144
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2143
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2145
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2146
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2132
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2133
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2134
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2135
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2122
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2123
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2124
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2125
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2126
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2127
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2128
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2129
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2110
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2111
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2112
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2113
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2085
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2102
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2103
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2104
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2105
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2106
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2107
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2108
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2109
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2097
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2098
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2099
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2100
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2101
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2086
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2087
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2088
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2089
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2090
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2091
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2092
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2093
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2094
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2095
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2084
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2096
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2078
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2079
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2080
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2081
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2082
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2083
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2072
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2073
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2074
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2075
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2076
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2077
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2071
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2067
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2068
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2069
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2066
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2058
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2059
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2060
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2061
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2062
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2063
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2064
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2065
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2054
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2055
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2056
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2057
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2049
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2050
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2051
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2052
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2053
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2048
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2046
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2047
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2039
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2040
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2041
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2042
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2043
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2044
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2045
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2038
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2034
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2035
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2036
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2037
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2033
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2716
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2024
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2032
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2026
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2027
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2028
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2029
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2030
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2031
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2022
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2019
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2020
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2021
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2013
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2014
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2015
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2016
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2017
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2018
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2012
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2011
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2007
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2008
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2005
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2006
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2002
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2004
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2000
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2001
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1997
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1999
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1998
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1994
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1996
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1995
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1993
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1990
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1991
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1992
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1988
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1986
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1987
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1982
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1983
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1984
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1985
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1980
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1981
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1972
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1979
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1974
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1975
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1976
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1977
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1978
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1970
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1971
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1973
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1966
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1967
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1969
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1960
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1961
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1962
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1963
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1964
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1965
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1959
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1956
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1957
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1958
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1953
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1954
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1955
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2009
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1951
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1952
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1949
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1950
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1946
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1947
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1948
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1941
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1943
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1944
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1934
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1935
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1936
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1937
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1938
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1931
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1932
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1933
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1927
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1928
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1929
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1930
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2486
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2487
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1924
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1925
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1926
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1918
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1919
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1920
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1921
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1922
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1923
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1910
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1911
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1913
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1914
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1915
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1916
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1908
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1909
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1907
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1906
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1896
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1897
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1898
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1899
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1900
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1901
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1902
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1903
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1904
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1905
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1892
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1893
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1894
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1895
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1886
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1887
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1888
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1890
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1891
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1864
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1881
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1882
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1883
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1885
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1877
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1878
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1879
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1880
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1876
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1871
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1872
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1873
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1874
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1875
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1870
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1865
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1866
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1867
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1868
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1869
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1863
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1861
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1856
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1857
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1859
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1860
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1862
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1855
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1849
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1850
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1851
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1852
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1853
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1854
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1847
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1848
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1846
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1845
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1842
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1843
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1844
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1838
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1839
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1840
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1841
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1837
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1832
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1833
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1834
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1835
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1836
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1831
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1828
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1829
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1830
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1822
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1823
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1824
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1825
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1826
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1827
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1817
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1818
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1819
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1820
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1821
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1813
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1814
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1815
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1816
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1810
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1811
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1812
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1809
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1808
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1806
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1807
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1804
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1805
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1803
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1801
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1802
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1800
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1799
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1798
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1797
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1793
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1794
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1795
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1796
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1792
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1787
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1788
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1789
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1790
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1786
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1781
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1782
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1784
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1779
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1780
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1774
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1775
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1776
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1777
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1778
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1773
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1769
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1772
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1771
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1768
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1765
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1766
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1767
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1762
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1763
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1759
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1760
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1761
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1764
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1756
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1757
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1758
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1755
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1749
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1750
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1751
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1752
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1753
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1754
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1746
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1747
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1748
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1740
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1741
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1742
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1743
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1745
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1737
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1738
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1739
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1731
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1732
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1733
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1734
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1735
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1736
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1729
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1730
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1728
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1725
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1726
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1727
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1722
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1723
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1724
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1721
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1718
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1719
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1720
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1717
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1714
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1715
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1716
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1711
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1712
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1713
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1710
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1708
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1709
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1704
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1705
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1706
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1707
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1702
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1703
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1698
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1699
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1700
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1701
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1694
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1695
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1696
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1697
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1688
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1689
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1690
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1691
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1692
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1693
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1685
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1686
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1687
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1684
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1683
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1680
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1681
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1682
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1679
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1674
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1675
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1676
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1677
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1678
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1673
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1671
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1672
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1670
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1669
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1667
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1668
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1662
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1663
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1664
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1665
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1661
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1657
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1658
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1659
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1660
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1656
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1651
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1652
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1653
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1654
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1655
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1650
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1649
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1648
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1646
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1647
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1644
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1645
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1642
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1643
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1641
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1638
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1639
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1637
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1636
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1634
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1635
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1633
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1632
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1630
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1631
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1629
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1628
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1627
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1626
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1624
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1625
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1621
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1622
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1623
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1620
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1619
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1618
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1616
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1617
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1614
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1615
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1612
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1613
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1610
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1609
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1607
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1608
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1606
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1605
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1604
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1601
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1603
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1599
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1600
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1598
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1597
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1596
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1602
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1595
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1594
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1593
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1592
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1591
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1589
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1590
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1588
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1585
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1586
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1583
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1584
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1582
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1580
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1581
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1579
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1578
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1576
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1577
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1573
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1574
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1575
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1572
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1570
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1571
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1568
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1569
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1566
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1567
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1563
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1564
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1565
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1561
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1562
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1559
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1560
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1557
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1558
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1554
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1555
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1556
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1552
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1553
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1549
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1550
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1551
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1547
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1548
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1544
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1545
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1546
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1541
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1543
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1534
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1535
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1540
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1538
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1536
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1537
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1587
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1532
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1531
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1533
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1529
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1530
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1527
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1528
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1525
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1526
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1523
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1524
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1520
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1521
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1522
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1517
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1518
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1519
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1514
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1516
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1513
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1511
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1512
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1508
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1509
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1506
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1507
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1504
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1505
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1501
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1502
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1503
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1499
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1500
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1498
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1497
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1496
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1495
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1493
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1494
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1491
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1492
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1489
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1490
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1485
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1487
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1488
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1481
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1482
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1483
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1479
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1480
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1478
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1477
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1473
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1474
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1469
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1470
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1466
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1467
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1463
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1464
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1465
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1471
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1472
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1458
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1462
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1468
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1461
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1456
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1457
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1452
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1455
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1460
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1451
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1454
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1484
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1450
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1449
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1448
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1447
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1446
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1445
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1444
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1443
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1442
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1441
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1440
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1439
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1437
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1438
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1435
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1434
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1431
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1430
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1428
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1429
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1425
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1426
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1427
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1424
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1423
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1420
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1421
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1422
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1418
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1419
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1414
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1410
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1407
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1408
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1405
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1406
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1401
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1402
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1403
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1400
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1399
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1398
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1397
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1396
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1395
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1394
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1393
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1391
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1392
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1389
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1390
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1388
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1387
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1386
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1385
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1384
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1383
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1382
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1381
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1378
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1379
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1375
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1376
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1374
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1373
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1371
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1372
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1369
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1370
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1368
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1365
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1366
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1367
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1364
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1361
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1362
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1363
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1360
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1359
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1358
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1355
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1356
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1357
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1354
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1353
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1352
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1351
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1350
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1349
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1347
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1345
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1346
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1344
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1343
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1342
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1340
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1341
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1337
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1338
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1339
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1335
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1336
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1334
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1333
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1332
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1329
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1330
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1331
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1326
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1327
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1328
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1323
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1324
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1325
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1321
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1322
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1320
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1318
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1319
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1317
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1316
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1313
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1314
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1315
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1312
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1311
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1309
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1308
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1306
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1307
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1304
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1305
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1301
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1302
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1303
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1300
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1299
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1296
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1297
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1298
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1294
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1295
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1293
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1289
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1290
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1291
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1292
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1288
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1286
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1287
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1280
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1281
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1282
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1283
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1284
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1276
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1277
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1278
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1279
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1273
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1274
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1275
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1270
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1271
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1272
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1267
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1268
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1269
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1265
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1266
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1263
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1264
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1262
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1261
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1259
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1260
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1254
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1255
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1256
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1257
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1258
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1251
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1252
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1253
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1248
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1249
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1250
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1247
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1246
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1242
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1243
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1244
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1245
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1240
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1241
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1238
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1239
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1235
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1236
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1237
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1233
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1234
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1231
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1232
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1228
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1229
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1230
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1226
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1227
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1224
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1225
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1222
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1223
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1221
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1218
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1219
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1220
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1216
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1217
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1214
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1215
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1210
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1211
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1212
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1213
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1208
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1209
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1206
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1207
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1205
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1201
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1203
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1204
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1200
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1202
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1198
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1199
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1196
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1197
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1194
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1195
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1188
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1189
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1190
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1191
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1192
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1193
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1182
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1183
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1187
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1180
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1181
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1177
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1176
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1174
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1175
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1172
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1173
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1171
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1163
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1164
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1167
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1170
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1169
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1162
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1155
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1161
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1160
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1157
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1158
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1159
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1153
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1154
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1156
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1152
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1149
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1150
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1151
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1148
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1147
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1145
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1146
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1142
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1143
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1144
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1139
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1140
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1141
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1138
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1137
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1135
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1136
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1133
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1134
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1132
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1128
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1129
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1130
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1131
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1126
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1127
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1125
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1123
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1124
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1121
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1122
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1120
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1119
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1118
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1117
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1116
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1114
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1115
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1112
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1113
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1110
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1111
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1104
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1106
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1107
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1108
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1109
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1103
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1105
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1102
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1101
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1097
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1099
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1100
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1098
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1094
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1095
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1096
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1093
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1090
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1091
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1092
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1089
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1087
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1088
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1084
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1085
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1086
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1083
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1078
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1081
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1082
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1075
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1076
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1077
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1072
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1073
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1074
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1064
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1067
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1071
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1068
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1066
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1062
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1065
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1063
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1058
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1059
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1060
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1061
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1057
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1056
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1054
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1055
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1053
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1050
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1051
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1052
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1044
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1045
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1046
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1047
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1048
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1049
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1040
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1041
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1042
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1043
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1039
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1038
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1036
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1037
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1035
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1033
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1034
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1031
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1032
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1030
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1028
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1029
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1024
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1025
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1026
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1027
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1023
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1022
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1021
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1020
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1019
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1013
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1017
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1018
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1015
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1012
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1014
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1011
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1010
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1004
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1005
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1006
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1007
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1008
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1009
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1000
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1001
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1002
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1003
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=997
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=998
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=999
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=996
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=994
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=995
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=991
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=986
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=990
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=992
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=988
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=989
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=993
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=982
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=983
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=981
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=978
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=979
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=980
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=976
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=977
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=973
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=974
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=975
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=970
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=972
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=971
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=968
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=969
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=967
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=966
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=963
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=964
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=962
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=958
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=961
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=957
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=951
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=952
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=954
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=955
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=956
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=949
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=950
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=948
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=945
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=946
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=947
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=944
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=934
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=935
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=936
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=937
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=938
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=939
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=940
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=941
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=942
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=943
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=930
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=931
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=932
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=933
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=929
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=923
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=924
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=925
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=926
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=927
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=921
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=922
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=920
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=918
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=919
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=917
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=915
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=916
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=910
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=913
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=914
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=912
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=907
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=908
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=909
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=904
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=905
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=906
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=902
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=903
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=901
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=899
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=900
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=897
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=894
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=896
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=893
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=887
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=888
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=889
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=890
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=891
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=892
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=885
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=886
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=881
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=882
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=883
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=884
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=879
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=880
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=878
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=875
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=873
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=874
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=876
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=877
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=871
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=872
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=870
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=869
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=867
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=868
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=864
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=865
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=866
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=862
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=863
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=861
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=859
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=860
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=858
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=856
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=857
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=855
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=853
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=854
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=850
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=851
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=852
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=849
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=845
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=846
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=847
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=848
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=843
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=844
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=841
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=842
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=839
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=837
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=838
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=835
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=836
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=831
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=832
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=833
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=834
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=830
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=827
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=828
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=829
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=824
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=825
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=826
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=817
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=818
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=819
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=820
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=821
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=822
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=823
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=816
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=815
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=812
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=813
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=814
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=807
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=810
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=811
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=806
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=808
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=809
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=805
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=801
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=802
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=803
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=804
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=800
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=799
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=795
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=791
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=792
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=793
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=794
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=788
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=789
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=790
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=787
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=785
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=783
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=782
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=780
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=779
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=776
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=777
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=778
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=775
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=774
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=770
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=771
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=772
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=773
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=769
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=767
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=766
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=763
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=764
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=762
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=759
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=760
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=761
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=959
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=756
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=757
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=758
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=753
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=750
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1432
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1433
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=749
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=746
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=745
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=743
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=740
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=741
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=742
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=737
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=738
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=736
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=735
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=733
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=730
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=732
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=729
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=728
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=723
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=724
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=725
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=726
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=727
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=722
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=721
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=720
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=718
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=716
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=717
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=712
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=713
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=709
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=710
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=711
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=708
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=706
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=705
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=703
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=704
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=701
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=702
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=698
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=699
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=700
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=696
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=697
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=695
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=693
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=694
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=689
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=690
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=691
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=692
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=687
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=688
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=686
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=679
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=681
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=682
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=683
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=684
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=678
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=677
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=676
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=673
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=674
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=675
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=671
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=672
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=669
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=670
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=668
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=662
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=663
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=664
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=665
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=666
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=661
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=659
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=660
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=654
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=655
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=656
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=657
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=658
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=649
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=650
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=651
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=652
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=653
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=648
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=646
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=647
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=645
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=642
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=643
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=644
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=639
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=640
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=638
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=635
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=636
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=637
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=633
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=632
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=624
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=627
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=630
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=631
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=620
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=621
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=622
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=619
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=618
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=616
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=617
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=634
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=611
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=604
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=605
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=607
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=608
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=609
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=610
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=603
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=601
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=600
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=602
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=599
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=598
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=596
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=587
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=588
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=589
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=590
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=591
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=592
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=593
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=594
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=595
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=586
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=582
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=581
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=578
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=579
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=574
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=573
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=572
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=571
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=567
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=568
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=561
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=562
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=564
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=565
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=566
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=559
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=560
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=553
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=554
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=548
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=549
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=551
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=547
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=536
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=537
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=538
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=539
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=540
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=541
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=542
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=543
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=544
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=545
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=528
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=529
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=530
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=531
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=527
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=525
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=526
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=523
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=520
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=521
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=522
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=519
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=517
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=518
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=516
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=514
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=513
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=512
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=511
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=510
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=508
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=509
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=505
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=506
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=500
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=501
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=502
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=503
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=504
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=495
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=496
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=497
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=498
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=515
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=491
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=492
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=493
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=494
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=489
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=487
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=488
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=485
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=475
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=476
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=477
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=478
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=479
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=480
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=481
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=482
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=483
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=484
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=474
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=473
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=472
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=470
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=466
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=467
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=468
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=465
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=464
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=463
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=461
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=446
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=447
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=448
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=449
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=450
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=451
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=452
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=453
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=456
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=457
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=458
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=459
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=460
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=455
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=445
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=444
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=443
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=441
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=442
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=439
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=426
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=428
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=429
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=430
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=431
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=432
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=433
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=434
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=435
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=436
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=437
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=438
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=425
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=423
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=424
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=418
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=420
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=422
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=416
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=417
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=415
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=414
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=413
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=409
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=410
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=411
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=412
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=408
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=407
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=403
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=405
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=402
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=392
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=393
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=394
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=395
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=396
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=397
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=398
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=399
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=400
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=401
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=391
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=390
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=388
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=386
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=387
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=381
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=382
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=385
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=379
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=377
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=378
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=370
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=371
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=372
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=373
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=374
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=375
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=376
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=369
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=364
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=363
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=362
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=361
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=351
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=352
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=353
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=354
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=355
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=356
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=357
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=347
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=346
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=338
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=342
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=344
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=328
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=331
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=332
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=333
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=334
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=335
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=324
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=323
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=329
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=319
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=321
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=322
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=315
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=316
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=305
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=306
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=307
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=308
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=309
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=310
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=313
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=303
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=301
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=296
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=297
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=298
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=299
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=300
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=294
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=295
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=288
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=287
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=274
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=275
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=276
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=277
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=278
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=279
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=283
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=281
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=282
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=284
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=286
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=272
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=262
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=263
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=264
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=265
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=266
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=267
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=268
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=269
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=270
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=271
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=260
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=261
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=258
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=257
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=246
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=247
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=249
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=251
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=252
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=253
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=254
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=255
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=256
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=244
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=245
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=243
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=241
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=239
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=240
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=238
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=237
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=236
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=228
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=234
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=223
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=224
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=225
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=226
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=229
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=230
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=231
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=232
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=222
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=210
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=211
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=212
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=213
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=214
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=215
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=216
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=217
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=218
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=219
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=198
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=199
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=200
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=201
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=202
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=203
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=204
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=205
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=206
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=207
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=208
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=197
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=196
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=192
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=182
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=183
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=184
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=185
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=186
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=188
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=189
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=190
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=191
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=187
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=180
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=170
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=171
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=172
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=173
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=175
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=176
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=177
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=178
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=179
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=168
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=157
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=158
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=159
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=160
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=162
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=163
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=164
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=165
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=166
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=194
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=155
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=146
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=147
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=148
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=149
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=150
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=151
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=152
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=153
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=154
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=156
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=140
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=141
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=131
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=132
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=133
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=134
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=135
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=136
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=137
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=138
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=139
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=118
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=119
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=120
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=121
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=122
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=123
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=124
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=125
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=126
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=128
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=105
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=109
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=110
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=111
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=112
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=113
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=114
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=115
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=116
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=117
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=88
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=97
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=98
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=99
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=100
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=101
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=102
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=103
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=104
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=86
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=87
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=89
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=90
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=91
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=92
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=93
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=94
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=80
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=82
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=71
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=72
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=73
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=79
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=81
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=75
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=76
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=77
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=78
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=59
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=60
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=61
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=62
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=64
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=65
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=66
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=67
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=68
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=55
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=50
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=39
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=43
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=44
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=45
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=46
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=47
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=53
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=52
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=38
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=42
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=41
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=28
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=31
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=29
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=30
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=32
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=33
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=34
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=35
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=36
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=20
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=21
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=22
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=23
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=24
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=25
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=26
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=15
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=18
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=9
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=10
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=11
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=12
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=13
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=14
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=16
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=6
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=4
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=7
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=8
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1744
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1377
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1412
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1413
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1417
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1939
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1940
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1942
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=1989
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2121
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2159
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2197
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2227
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2228
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2338
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2821
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=2906
    http://www.fedearroz.com.co/noticias/noticiasd2.php?id=3081
    2943
    


```python
#html = requests.get(datos[25]).text
#soup = BeautifulSoup(html)
#type(soup)
#fechas=[]
#titulos= soup.find_all('h1')
#fechas.append(soup.find_all('b'))
#contenido =  soup.find_all('p',{"class": "body"})
#notiteca.append(soup)
#print(titulos)   
#print(fechas)
#print(contenido)
```


```python
date  = []
title = []
body  = []

#for i in range(2942):
 #   html = requests.get(datos[i]).text
  #  soup = BeautifulSoup(html)
   # type(soup)
    #date.append(soup.find_all('b')) 
```


```python
#print(date[50][0])
#n = len(date)
#print (n)
#fecha =[]
#for i in range(n):
 #   if i != 32 or i != 50:
 #       temporal = str(date[i][0])
 #       temporal = re.sub('<b>|</b>', '',temporal)
 #       print(i,": ",temporal)
```


```python
html2 = requests.get('http://www.fedearroz.com.co/new/noticias.php').text
soup2 = BeautifulSoup(html2)
type(soup2)
soup2
fecha = soup2.find_all('span',{"class": "fecha"})
fechas=[]
#print(fecha)
```


```python
n= len(fecha)
fechas_unidas=''
años =[]
for i in range(n):
   
    temporal = str(fecha[i])
    temporal = re.sub('<span|class="fecha">|</span>', '',temporal)
    año = re.findall('[0-9]+', temporal)
    años.append(año)
    fechas_unidas = fechas_unidas+temporal
    fechas.append(temporal)


```


```python
notiXaño = []
añolabel = []
actual = 2020
contador = 0

n= len(años)
#print (n)
for i in range(n):
    if(actual!=2007):
        if años[i][1] == str(actual):
            contador = contador+1
        else:  
            notiXaño.append(contador)
            añolabel.append(actual)
            
            actual = actual-1
            contador = 0
    else:
        i=i+n
```


```python
tabla=[]
tabla.append(añolabel)
tabla.append(notiXaño) 
```

<div style="text-align: center; font-size:12px;"> <h1>Años mas relevantes para el gremio Arrocero</h1></div>


```python
print(tab.tabulate(tabla, headers='firstrow',tablefmt='fancy_grid'))
plt.pie(notiXaño, labels=añolabel)
plt.show()

```

    ╒════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╤════════╕
    │   2020 │   2019 │   2018 │   2017 │   2016 │   2015 │   2014 │   2013 │   2012 │   2011 │   2010 │   2009 │   2008 │
    ╞════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╪════════╡
    │    164 │    259 │    305 │    330 │    163 │    165 │    288 │    310 │    328 │    147 │    155 │    176 │    123 │
    ╘════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╧════════╛
    


    
![png](output_10_1.png)
    



```python
titulos =[]
uni_titulos=''

texto =[]
textosunidos =''

for i in range(2942):
    html = requests.get(datos[i]).text
    soup = BeautifulSoup(html)
    type(soup)
    title.append(soup.find_all('h1'))
    
    temporal = str(title[i])
    temporal = re.sub('<h1>|</h1>', '',temporal)
    temporal = temporal.replace('[','')
    temporal = temporal.replace(']','')
    uni_titulos=uni_titulos+temporal
    titulos.append(temporal)
    
    body.append(soup.find_all('p',{"class": "body"})) 
    
    temporal2 = str(body[i])
    temporal2 = re.sub('\xa0\xa0|<p|class="body">|\n|</p>|<br/>|align="right"|vspace="5"/>|align="default"|</u>','',temporal2)
    temporal2 = temporal2.replace('[','')
    temporal2 = temporal2.replace(']','')
    textosunidos = textosunidos+ temporal2
    texto.append(temporal2)
    
```


```python
#print(titulos)
```


```python

    
```


```python

```

# 1 DEPARTAMENTOS EN TENDENCIA


```python
textosunidostxt = str(textosunidos)
departamentos = ['Bogotá','Amazonas','Antioquía','Arauca','Atlántico','Bolívar',
'Boyacá','Caldas','Caquetá','Casanare','Cauca','Cesar','Chocó','Córdoba','Cundinamarca',
'Guainía','Guaviare','Huila','La','Magdalena','Meta','Nariño','Norte','Putumayo','Quindío',
'Risaralda','San','Santander','Sucre','Tolima','Valle','Vaupés','Vichada']
grafica_dp =[None]*len(departamentos)
for i in range(len(departamentos)):
    print(departamentos[i],': ',textosunidostxt.count(departamentos[i]))
    grafica_dp[i]=[departamentos[i],textosunidostxt.count(departamentos[i])]
```

    Bogotá :  26
    Amazonas :  1
    Antioquía :  3
    Arauca :  44
    Atlántico :  3
    Bolívar :  20
    Boyacá :  0
    Caldas :  21
    Caquetá :  1
    Casanare :  211
    Cauca :  180
    Cesar :  155
    Chocó :  4
    Córdoba :  102
    Cundinamarca :  46
    Guainía :  0
    Guaviare :  9
    Huila :  164
    La :  2146
    Magdalena :  114
    Meta :  208
    Nariño :  0
    Norte :  121
    Putumayo :  23
    Quindío :  2
    Risaralda :  21
    San :  803
    Santander :  186
    Sucre :  166
    Tolima :  331
    Valle :  191
    Vaupés :  0
    Vichada :  10
    

# 2 Presidentes Nombrados


```python
tot = textosunidostxt.count('Iván Duque') + textosunidostxt.count('Uribe')+textosunidostxt.count('Santos')

print('Duque',textosunidostxt.count('Iván Duque')*100/tot)
print('Duque',uni_titulos.count('Iván Duque'))

print('Uribe',textosunidostxt.count('Uribe'))
print('Uribe',uni_titulos.count('Uribe:'))

print('Juan manuel Santos',textosunidostxt.count('Santos'))
print('Juan manuel Santos',uni_titulos.count('Santos'))
```

    Duque 1.935483870967742
    Duque 1
    Uribe 49
    Uribe 1
    Juan manuel Santos 103
    Juan manuel Santos 5
    

# 3 PLAGA


```python
print('Plaga',textosunidostxt.count('plagas'))
print('Plaga',textosunidostxt.count('Oryzophagus'))
print('Oebalus',textosunidostxt.count('Oebalus'))
print('Spodoptera',textosunidostxt.count('Spodoptera'))
print('Insectos',textosunidostxt.count('insectos'))
print('Helminthosporium',textosunidostxt.count('Helminthosporium'))
print('Rhizoctonia',textosunidostxt.count('Rhizoctonia'))
```

    Plaga 138
    Plaga 0
    Oebalus 4
    Spodoptera 22
    Insectos 194
    Helminthosporium 4
    Rhizoctonia 17
    

# 4 Sanciones por libre competencia 


```python
print('Arroz Roa',textosunidostxt.count(' roa '))
print('Cartel',textosunidostxt.count('Cartel'))
print('Sanción',textosunidostxt.count('sanción'))
print('Flor huila',textosunidostxt.count('Flor huila'))
print('Consejo de estado',textosunidostxt.count('Consejo de estado'))
print('UNIÓN DE ARROCEROS',textosunidostxt.count('UNIÓN DE ARROCEROS'))
```

    Arroz Roa 0
    Cartel 0
    Sanción 0
    Flor huila 0
    Consejo de estado 0
    UNIÓN DE ARROCEROS 0
    

# Contrabando


```python
print('Peru',textosunidostxt.count('Peru'))
print('Uruguay',textosunidostxt.count('Uruguay'))
print('Estados unidos',textosunidostxt.count('Estados Unidos'))
print('Venezuela',textosunidostxt.count('Venezuela'))
print('Ecuador',textosunidostxt.count('Ecuador'))
```

    Peru 3
    Uruguay 15
    Estados unidos 182
    Venezuela 79
    Ecuador 83
    


```python
#print(textosunidostxt)
```


```python

```


```python
textosunidostxt=re.sub('hspace="5"|border="1"|<img|align="right"|vspace="5"/>|align="default"|</u>|align="left"','',textosunidostxt)
listaPalabras = textosunidostxt.split()

```


```python
#print(listaPalabras)
frecuenciaPalab = []
for w in listaPalabras:
    frecuenciaPalab.append(listaPalabras.count(w))

#print("Lista\n" + str(listaPalabras) + "\n")
#print("Frecuencias\n" + str(frecuenciaPalab) + "\n")
print("Pares\n" + str(list(zip(listaPalabras, frecuenciaPalab))))

```


```python

palabras = [w for w in listaPalabras if len(w) > 4]

#print (sorted(palabras))

print("Lista de palabras mayores a 4 letras")

frecuencia = FreqDist(palabras)
print(frecuencia)
print("")
print("LAS QUE MAS SE REPITEN")

grafica=frecuencia.most_common(30)
grafica
```

    Lista de palabras mayores a 4 letras
    <FreqDist with 51968 samples and 274130 outcomes>
    
    LAS QUE MAS SE REPITEN
    




    [('arroz', 1529),
     ('Fedearroz', 1238),
     ('sobre', 1122),
     ('manejo', 1042),
     ('entre', 997),
     ('Nacional', 966),
     ('agricultores', 956),
     ('cultivo', 930),
     ('sector', 866),
     ('productores', 855),
     ('desarrollo', 810),
     ('Agricultura', 797),
     ('programa', 764),
     ('producci�n', 739),
     ('donde', 725),
     ('Desarrollo', 706),
     ('millones', 645),
     ('campo', 564),
     ('importancia', 562),
     ('parte', 558),
     ('Ministerio', 553),
     ('conocer', 535),
     ('condiciones', 498),
     ('arroz,', 482),
     ('mayor', 473),
     ('tiene', 473),
     ('evento', 463),
     ('cultivos', 458),
     ('Masiva', 455),
     ('recursos', 452)]




```python
#grafica

x=[]
y= []

for i in range(len(grafica)):
    x.append(grafica[i][1])
    y.append(grafica[i][0])
    
s=len(x)    
plt.figure(figsize=(20,10))    
plt.bar(range(s), x, edgecolor='black')

plt.xticks(range(s), y, rotation=60)
plt.title("PALABRAS REPETIDAS")
plt.ylim(min(x)-1, max(x)+1)
plt.show()

```


    
![png](output_30_0.png)
    



```python
plt.pie(notiXaño, labels=añolabel)
plt.show()
```


    
![png](output_31_0.png)
    



```python
#print(titulos[10])
#print(texto[10])

print(len(titulos))
print(len(texto))
print(len(años))


```


```python
texto[7]


```


```python
Euu_ctlc =[]
Ven_ctlc =[]
Ecu_ctlc =[]
nE = 0
nV = 0
nEc = 0
actual = 2020
for i in range(2924):
    
    if(actual!=2007):
        
        añ = int(años[i][1])
        
        textotp = str(texto[i]) 
        #textotp = str(titulos[i]) 
       
        if  añ == actual :
                
                nE = nE +textotp.count('Estados Unidos')
                nV = nV +textotp.count('Venezuela')
                nEc = nEc +textotp.count('Ecuador')
        else:
            
            Euu_ctlc.append([actual,nE])
            Ven_ctlc.append([actual,nV])
            Ecu_ctlc.append([actual,nEc])
            nE = 0
            nV = 0
            nEc = 0
            actual = actual-1
            i=i-1
            
    else:
        print(actual,"notengo noticias")
        i=i*2020
        
         #print(año[i][1],": ",textotp.count('Estados Unidos'))
            
    
```


```python
x=[]
y= []

x2=[]
x3=[]
for i in range(len(Euu_ctlc)):
    x.append(Euu_ctlc[11-i][1])
    x2.append(Ven_ctlc[11-i][1])
    x3.append(Ecu_ctlc[11-i][1])
    y.append(Euu_ctlc[11-i][0])
    
s=len(y)    
plt.figure(figsize=(20,10))

plt.plot(y, x,'c')
plt.plot(y, x2,'b')
plt.plot(y, x3,'y')
plt.legend(['EUU','VENEZUELA','ECUADOR'], loc=1)
plt.title("TLC ESTADOS UNIDOS")
plt.ylabel("PORCENTAJE")
plt.ylim(min(x)-1, max(x)+1)

plt.show()
```


    
![png](output_35_0.png)
    



```python

```
